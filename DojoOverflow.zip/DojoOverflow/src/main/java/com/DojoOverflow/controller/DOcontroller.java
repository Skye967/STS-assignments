package com.DojoOverflow.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.DojoOverflow.Answer;
import com.DojoOverflow.Question;
import com.DojoOverflow.QuestionTag;
import com.DojoOverflow.Tag;
import com.DojoOverflow.services.DojoOverflowService;

@Controller
public class DOcontroller {
	private List<String> tagList = new ArrayList<>();
	private final DojoOverflowService DOservice;
	
	
	public DOcontroller(DojoOverflowService DOservice) {
		this.DOservice = DOservice;
	}
	
	
	@RequestMapping("/")
	public String index(Model model) {
		List<Question> questions = DOservice.allQuestions();
		List<QuestionTag> tags = DOservice.allQT();
		HashMap<String, String> questionTagMap = new HashMap<String, String>();
		for(int i=0; i<questions.size(); i++) {
			long questionID = questions.listIterator(i).next().getId();
			String tagString = "";
			for(int x=0; x<tags.size(); x++) {
				long tagID = tags.listIterator(x).next().getQuestion().getId();
				if(questionID == tagID) {
					String addTagtoString = tags.listIterator(x).next().getTag().getSubject();
					tagString += addTagtoString + ", ";
				}
				if(x == tags.size()-1) {
					String Q = questions.listIterator(i).next().getQuestion();
					questionTagMap.put(Q, tagString);
				}
			}
		}
		model.addAttribute("QTlist", questionTagMap);
		return "index.jsp";
	}
	
	
	@RequestMapping("/new/question")
	public String newQuestion(@ModelAttribute("thisquestion")Question question) {
		return "newQuestion.jsp";
	}
	
	
	
	@SuppressWarnings("unlikely-arg-type")
	@RequestMapping(value="/new/question", method=RequestMethod.POST)
	public String createQuestion(@Valid @ModelAttribute("thisquestion") Question question, BindingResult result, @RequestParam("tag") String tag) {
		if(result.hasErrors()) {
			return "rediect:/new/question";
		}
		String tagString = "";
		for(int i = 0; i < tag.length(); i++) {
			if(tag.charAt(i) != ' ' && tag.charAt(i) != ',' ) {
				tagString += tag.charAt(i);
			} 
			if(tag.charAt(i) == ',' || i == tag.length() - 1 ) {
				this.tagList.add(tagString.toLowerCase());
				tagString = "";
			}
		}
		Set<String> hash = new HashSet<>();
		hash.addAll(this.tagList);
		this.tagList.clear();
		this.tagList.addAll(hash);
		Question saveQuestion = DOservice.createQuestion(question);
		for(String val:this.tagList) {
			if(DOservice.allTags().contains(val) == false) {
				Tag addTag = new Tag();
				addTag.setSubject(val);
				System.out.println(saveQuestion.getTags());
				DOservice.createTag(addTag);
				QuestionTag testQT = DOservice.createQuestionTag(saveQuestion, addTag);
			}else {
				DOservice.createQuestionTag(saveQuestion, DOservice.findTagBySubject(val));
			}
		}
		this.tagList.clear();
		return "redirect:/";
	}
	
	
	@RequestMapping("/display/answers/{ByQuestion}")
	public String showAnswers(@PathVariable("ByQuestion") String ByQuestion, Model Qmodel, Model tagModel, @ModelAttribute("addAnswer") Answer addAnswer, Model modelAnswers) {
		Question thisQuestion = DOservice.findQuestionByQuestion(ByQuestion);
		List<QuestionTag> tagList = DOservice.findQuestionsInQT(thisQuestion.getId());
		Qmodel.addAttribute( "displayQuestion", thisQuestion);
		tagModel.addAttribute("tagList", tagList);
		List<Answer> listAnswers = DOservice.findAnswerbyQuestionID(thisQuestion.getId());
		modelAnswers.addAttribute("listAnswers", listAnswers);
		return "answer.jsp";
	}
	
	
	@RequestMapping(value="/new/answer/{Q}", method=(RequestMethod.POST))
	public String addAnswer(@Valid @ModelAttribute("addAnswer") Answer addAnswer, BindingResult result, @PathVariable("Q") String Qid) {
		if(result.hasErrors()) {
			System.out.println("errors");
			return "redirect:/display/answers/{Qid}";
		}
		DOservice.createAswer(addAnswer);
		System.out.println("works");
		return "redirect:/";
	}
	
}










