package com.DojoOverflow.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.DojoOverflow.Answer;
import com.DojoOverflow.Question;
import com.DojoOverflow.QuestionTag;
import com.DojoOverflow.Tag;
import com.DojoOverflow.Repositories.AnswerRepo;
import com.DojoOverflow.Repositories.QuestionRepo;
import com.DojoOverflow.Repositories.QuestionTagRepo;
import com.DojoOverflow.Repositories.TagRepo;
@Service
public class DojoOverflowService {
	private final QuestionRepo questionRepo;
	private final TagRepo tagRepo;
	private final QuestionTagRepo QTrepo;
	private final AnswerRepo answerRepo;
	
	
	
	public DojoOverflowService(QuestionRepo questionRepo, TagRepo tagRepo, QuestionTagRepo QTrepo,
			AnswerRepo answerRepo) {
		super();
		this.questionRepo = questionRepo;
		this.tagRepo = tagRepo;
		this.QTrepo = QTrepo;
		this.answerRepo = answerRepo;
	}
	
	public List<Question> allQuestions(){
		return questionRepo.findAll();
	}
	
	public List<Tag> allTags(){
		return tagRepo.findAll();
	}
	
	public List<QuestionTag> allQT(){
		return QTrepo.findAll();
	}
	
	public List<Answer> allAnswers(){
		return answerRepo.findAll();
	}

	public List<QuestionTag> findQuestionsInQT(Long id) {	
		return QTrepo.findByquestion_id(id);
	}

	public List<QuestionTag> findTagsInQT(Long id) {
		return QTrepo.findBytag_id(id);
	}
	
	public List<Answer> findAnswerbyQuestionID(Long id){
		return answerRepo.findByquestion_id(id);
	}
	
	public Question findQuestionByQuestion(String question) {
		return questionRepo.findByquestionContaining(question);
	}
	
	public Question createQuestion(Question Q) {
		return questionRepo.save(Q);
	}
	
	public Question addTag(Question Q, Tag T) {
		Question question = Q;
		question.addTags(T);
		return questionRepo.save(question);
	}
	
	public Tag createTag(Tag T) {
		return tagRepo.save(T);
	}
	
	public QuestionTag createQuestionTag(Question Q, Tag T) {
		QuestionTag createQT = new QuestionTag();
		createQT.setTag(T);
		createQT.setQuestion(Q);
		return QTrepo.save(createQT);
	}
	
	public Answer createAswer(Answer A) {
		return answerRepo.save(A);
	}

	public Tag findTagBySubject(String val) {
		return tagRepo.findBysubject(val);
	}

}
