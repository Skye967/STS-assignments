package com.DojoOverflow.Repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.DojoOverflow.Tag;

public interface TagRepo extends CrudRepository<Tag, Long>{
	Tag findBysubject(String tag);
	List<Tag> findAll();
}
