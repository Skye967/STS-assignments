package com.DojoOverflow.Repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.DojoOverflow.Question;

public interface QuestionRepo extends CrudRepository<Question, Long>{
	List<Question> findAll();
	Question findByquestionContaining(String question);
}
