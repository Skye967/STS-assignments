package com.DojoOverflow.Repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.DojoOverflow.Answer;

public interface AnswerRepo extends CrudRepository<Answer, Long>{
	List<Answer> findAll();
	List<Answer> findByquestion_id(Long id);
}
