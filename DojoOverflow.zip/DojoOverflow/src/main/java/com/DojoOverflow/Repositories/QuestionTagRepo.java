package com.DojoOverflow.Repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.DojoOverflow.QuestionTag;

public interface QuestionTagRepo extends CrudRepository<QuestionTag, Long>{
	List<QuestionTag> findAll();
	List<QuestionTag> findByquestion_id(Long id);
	List<QuestionTag> findBytag_id(Long id);
}
