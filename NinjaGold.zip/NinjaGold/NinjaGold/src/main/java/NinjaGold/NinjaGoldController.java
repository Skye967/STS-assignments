package NinjaGold;

import java.util.ArrayList;
import java.util.Date;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class NinjaGoldController {
	ArrayList<String> myList = new ArrayList<String>();
	public int gold = 0;
	
	
	@RequestMapping("/")
	public String ninja(HttpSession session ) {
		if(session.getAttribute("mylist") == null) {
			session.setAttribute("mylist", myList);
		}
		if(session.getAttribute("Gold") == null) {
			session.setAttribute("Gold", gold);
			
		} 
		return "index.jsp";
	}
	
	
	@RequestMapping("/remove")
	public String remove(@RequestParam(value="clear") String remove, HttpSession session ) {
		if(remove.equals("clear")) {
			session.invalidate();
			myList = new ArrayList<String>();
			gold = 0;
			System.out.print("works");
		}
		return "redirect:/";
	}
	
	
	@RequestMapping("/mining")
	public String mining(HttpSession session, @RequestParam(value="mining") String miner) {
			int rand = 0;
		if(miner.equals("farm")) {
			System.out.println("working");
			rand = (int) Math.floor((10 + (Math.random() * 20)));
		}
		if(miner.equals("cave") ) {
			rand = (int) Math.floor((5 + (Math.random() * 10)));
		}
		if(miner.equals("house")) {
			rand = (int) Math.floor((2 + (Math.random() * 5)));
		}
		if(miner.equals("casino")) {
			rand = -50 + (int) (Math.random() * ((50 - (-50)) + 1));
			System.out.println(rand);
		}
		Date happen = new Date();
		gold += rand;
		String activity = "You have just earned " + rand + " gold!" + happen ;
		myList.add(activity);
		session.setAttribute("mylist", myList);
		session.setAttribute("Gold", gold);
		System.out.println(myList);
		return "index.jsp";
	}
	
}
