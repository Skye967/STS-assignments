package com.ProductsAndCategories.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ProductsAndCategories.Category;
import com.ProductsAndCategories.CategoryProduct;
import com.ProductsAndCategories.Product;
import com.ProductsAndCategories.repositories.CategoryProductRepo;
import com.ProductsAndCategories.repositories.CategoryRepo;
import com.ProductsAndCategories.repositories.ProductRepo;

@Service
public class PnCservice {
	private final ProductRepo productRepo;
	private final CategoryRepo categoryRepo;
	private final CategoryProductRepo CPrepo;
	
	public PnCservice(ProductRepo productRepo, CategoryRepo categoryRepo, CategoryProductRepo CPrepo) {
		super();
		this.productRepo = productRepo;
		this.categoryRepo = categoryRepo;
		this.CPrepo = CPrepo;
	}


	
	public List<Product> allProducts(){
		return productRepo.findAll();
	}
	
	public List<Category> allCategories(){
		return categoryRepo.findAll();
	}
	
	
	public List<CategoryProduct> allCategoryProducts(){
		return CPrepo.findAll();
	}
	
	public List<CategoryProduct> listProductCategories(Long id){
		return CPrepo.findByproduct_id(id);
	}
	
	public List<CategoryProduct> listCategoryProducts(Long id){
		return CPrepo.findBycategory_id(id);
	}
	
	
	public Product createProduct(Product P) {
		return productRepo.save(P);
	}
	
	
	public Category createCategory(Category C) {
		return categoryRepo.save(C);
	}
	
	public CategoryProduct createCategoryProduct(CategoryProduct CP) {
		return CPrepo.save(CP);
	}
	
	
	
	public Product findProduct(Long id) {
		Optional<Product> optionalProduct = productRepo.findById(id);
		if(optionalProduct.isPresent()) {
			return optionalProduct.get();
		}else {
			return null;
		}
	}
	
	
	public Category findCategory(Long id) {
		Optional<Category> optionalCategory = categoryRepo.findById(id);
		if(optionalCategory.isPresent()) {
			return optionalCategory.get();
		}else {
			return null;
		}
	}
	
	
//	public Dojos updateLicense(Long id, String name, long rating) {
//		Optional<Dojos> dojo = dojoRepo.findById(id);
//		Dojos updateDojo;
//		if(dojo.isPresent()) {
//			updateDojo = dojo.get();
//		}else {
//			return null;
//		}
//		LocalDateTime myDateObj = LocalDateTime.now(); 
//		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-2022 HH:mm:ss");
//		Date newdate = new Date();
//		return dojoRepo.save(updateDojo);
//	}
//	


}
