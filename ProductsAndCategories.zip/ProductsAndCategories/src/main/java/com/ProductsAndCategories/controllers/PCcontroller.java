package com.ProductsAndCategories.controllers;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ProductsAndCategories.Category;
import com.ProductsAndCategories.CategoryProduct;
import com.ProductsAndCategories.Product;
import com.ProductsAndCategories.services.PnCservice;
@Controller
public class PCcontroller {
	private final PnCservice PCservice;

	public PCcontroller(PnCservice PCservice) {
		this.PCservice = PCservice;
	}
	
	
	@RequestMapping("/")
	public String index() {
		return "index.jsp";
	}
	
	@RequestMapping("/new/product")
	public String newProduct(@ModelAttribute("product") Product newProduct) {
		return "newProduct.jsp";
	}
	
	@RequestMapping(value="/product", method=RequestMethod.POST)
	public String createProduct(@ModelAttribute("product") Product createProduct, BindingResult result) {
		if(result.hasErrors()) {
			return "redirect:/new/product";
		}else {
			PCservice.createProduct(createProduct);
			return "redirect:/";
		}
	}
	
	@RequestMapping("/new/category")
	public String newCategory(@ModelAttribute("category") Product newCategory) {
		return "newCategory.jsp";
	}
	
	@RequestMapping(value="/category", method=RequestMethod.POST)
	public String createCategory(@ModelAttribute("category") Category createCategory, BindingResult result) {
		if(result.hasErrors()) {
			return "redirect:/new/category";
		}else {
			PCservice.createCategory(createCategory);
			return "redirect:/";
		}
	}	

	@RequestMapping("/product/display/{productID}")
	public String showProduct(@ModelAttribute("categoryProduct") CategoryProduct createCategoryProduct, @PathVariable("productID")Long productID, Model model, Model categoryModel, Model productCats) {
		System.out.println(createCategoryProduct.getId());
		Product product = PCservice.findProduct(productID);
		model.addAttribute("product", product);
		List<Category> CatList = PCservice.allCategories();
		List<CategoryProduct> CPlist = PCservice.listProductCategories(productID);
		for(int i=0; i<CPlist.size(); i++) {
			long CatRemove = CPlist.listIterator(i).next().getCategory().getId();
			for(int x=0; x<CatList.size(); x++) {
				if(CatList.listIterator(x).next().getId() == CatRemove) {
					Category Remove = CatList.listIterator(x).next();
					CatList.remove(Remove);
				}
			}
		}
		categoryModel.addAttribute("category", CatList);
		productCats.addAttribute("productCategories", CPlist);
		return "addProductCategory.jsp";
 	}
	
	@RequestMapping(value="/category/add/{productID}", method=RequestMethod.POST)
	public String addCategoryToProduct(@ModelAttribute("categoryProduct") CategoryProduct categoryProduct, BindingResult result, @PathVariable("productID")Long productID) {
		if(result.hasErrors()) {
			return "/product/display/{productID}";
		}else {
			PCservice.createCategoryProduct(categoryProduct);
			return "redirect:/";
		}	
	}
	
	
	@RequestMapping("/category/display/{categoryID}")
	public String showCategory(@ModelAttribute("form") CategoryProduct createCategoryProduct, @PathVariable("categoryID")Long categoryID, Model model, Model categoryModel, Model productCats) {
		Category category = PCservice.findCategory(categoryID);
		model.addAttribute("category", category);
		List<Product> ProdList = PCservice.allProducts();
		List<CategoryProduct> CPlist = PCservice.listCategoryProducts(categoryID);
		for(int i=0; i<CPlist.size(); i++) {
			long CatRemove = CPlist.listIterator(i).next().getCategory().getId();
			for(int x=0; x<ProdList.size(); x++) {
				if(ProdList.listIterator(x).next().getId() == CatRemove) {
					Product Remove = ProdList.listIterator(x).next();
					ProdList.remove(Remove);
				}
			}
		}
		categoryModel.addAttribute("products", ProdList);
		productCats.addAttribute("CategoryProducts", CPlist);
		return "addCategoryProduct.jsp";
 	}
	
	
	@RequestMapping(value="/product/add/{categoryID}", method=RequestMethod.POST)
	public String addProductToCategory(@ModelAttribute("form") CategoryProduct categoryProduct, BindingResult result, @PathVariable("categoryID")Long categoryID) {
		System.out.println(categoryProduct.getId());
		if(result.hasErrors()) {
			return "/product/display/{categoryID}";
		}else {
			PCservice.createCategoryProduct(categoryProduct);
			return "redirect:/";
		}	
	}
	
	
}







