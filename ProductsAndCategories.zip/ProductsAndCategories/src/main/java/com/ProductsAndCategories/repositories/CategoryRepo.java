package com.ProductsAndCategories.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ProductsAndCategories.Category;

public interface CategoryRepo extends CrudRepository<Category, Long>{
	
	List<Category> findAll();

}
