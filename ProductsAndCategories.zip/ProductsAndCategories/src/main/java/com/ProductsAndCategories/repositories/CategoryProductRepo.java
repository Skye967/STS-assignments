package com.ProductsAndCategories.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ProductsAndCategories.CategoryProduct;

public interface CategoryProductRepo extends CrudRepository<CategoryProduct, Long>{

	List<CategoryProduct> findAll();
	List<CategoryProduct> findByproduct_id(Long id);
	List<CategoryProduct> findBycategory_id(Long id);
}
