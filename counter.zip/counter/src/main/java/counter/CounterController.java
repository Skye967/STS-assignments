package counter;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CounterController {
	
	@RequestMapping("/counter")
	public String counter(HttpSession session) {
		if(session.getAttribute("count") == null) {
			session.setAttribute("count", 0);
		}else {
			Integer count = (Integer) session.getAttribute("count");
			count ++;
			session.setAttribute("count", count);
		}
		return "index.jsp";
	}
	
	
	@RequestMapping("/clear")
	public String clearSession(HttpSession session) {
		session.removeAttribute("count");
		return "index.jsp";
	}
	
	
	@RequestMapping("/")
	public String index(){
	  return "counter.jsp";
	}

}
