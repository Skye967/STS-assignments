package DisplayDate;



import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class displayDateController {
	
	
	@RequestMapping("/")
	public String Hello(){
		return "index.jsp";
	}
	
	@RequestMapping("/date")
	public String Date(Model model) {
		LocalDate date = LocalDate.now();
		model.addAttribute("something", date);
		return "date.jsp";
	}
	
	@RequestMapping("/time")
	public String time(Model model) {
		LocalTime time = LocalTime.now();
		model.addAttribute("something", time);
		return "time.jsp";
	}
}



