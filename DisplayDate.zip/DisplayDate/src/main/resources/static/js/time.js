/**
 * 
 */
   alert("This is the Time Template");