/**
 * 
 */
  alert("This is the Date Template");