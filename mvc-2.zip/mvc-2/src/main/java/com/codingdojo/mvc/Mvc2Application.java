package com.codingdojo.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mvc2Application {

	public static void main(String[] args) {
		SpringApplication.run(Mvc2Application.class, args);
	}

}
