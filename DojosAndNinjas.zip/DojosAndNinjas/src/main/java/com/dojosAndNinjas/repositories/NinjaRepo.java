package com.dojosAndNinjas.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.dojosAndNinjas.Ninja;

public interface NinjaRepo extends CrudRepository<Ninja, Long>{
	
	List<Ninja> findAll();
	List<Ninja> findBydojo_id(Long id);
	Long countBydojo_id(Long id);
}
