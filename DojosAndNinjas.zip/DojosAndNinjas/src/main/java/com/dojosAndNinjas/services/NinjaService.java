package com.dojosAndNinjas.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dojosAndNinjas.Dojo;
import com.dojosAndNinjas.Ninja;
import com.dojosAndNinjas.repositories.DojoRepo;
import com.dojosAndNinjas.repositories.NinjaRepo;
@Service
public class NinjaService {
	private final NinjaRepo ninjaRepo;
	private final DojoRepo dojoRepo;
	
	public NinjaService(NinjaRepo ninjaRepo, DojoRepo dojoRepo) {
		this.dojoRepo = dojoRepo;
		this.ninjaRepo = ninjaRepo;
	}
	
	public long countDojoNinjas(Long id) {
		return ninjaRepo.countBydojo_id(id);
	}
	
	public List<Ninja> allDojoNinjas(Long id){
		return ninjaRepo.findBydojo_id(id);
	}
	
	
	public List<Dojo> allDojos(){
		return dojoRepo.findAll();
	}
	
	public List<Ninja> allNinjas(){
		return ninjaRepo.findAll();
	}
	
	
	public Dojo createDojo(Dojo D) {
		return dojoRepo.save(D);
	}
	
	
	public Ninja createNinja(Ninja N) {
		return ninjaRepo.save(N);
	}
	
	
	
	public Dojo findDojo(Long id) {
		Optional<Dojo> optionalDojo = dojoRepo.findById(id);
		if(optionalDojo.isPresent()) {
			return optionalDojo.get();
		}else {
			return null;
		}
	}
	
	
	public Ninja findNinja(Long id) {
		Optional<Ninja> optionalNinja = ninjaRepo.findById(id);
		if(optionalNinja.isPresent()) {
			return optionalNinja.get();
		}else {
			return null;
		}
	}
	
	
//	public Dojos updateLicense(Long id, String name, long rating) {
//		Optional<Dojos> dojo = dojoRepo.findById(id);
//		Dojos updateDojo;
//		if(dojo.isPresent()) {
//			updateDojo = dojo.get();
//		}else {
//			return null;
//		}
//		LocalDateTime myDateObj = LocalDateTime.now(); 
//		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-2022 HH:mm:ss");
//		Date newdate = new Date();
//		return dojoRepo.save(updateDojo);
//	}
//	

}
