package com.dojosAndNinjas.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dojosAndNinjas.Dojo;
import com.dojosAndNinjas.Ninja;
import com.dojosAndNinjas.services.NinjaService;
@Controller
public class DnAcontroller {
	private final NinjaService ninjaService;

	public DnAcontroller(NinjaService ninjaService) {
		this.ninjaService = ninjaService;
	}
	
	@RequestMapping("/")
	public String index(Model dojoModel, Model countModel, Model dojosNninjas) {
		List<Dojo> dojos = ninjaService.allDojos();
		dojoModel.addAttribute("dojo", dojos);
		ArrayList<Long> ninjaCount = new ArrayList<Long>();
		countModel.addAttribute("count", ninjaCount);
		HashMap<String, Long> dojoNinjaCount = new HashMap<String, Long>();
		int x = 0;
		for (Dojo i : dojos) {
				ninjaCount.add(ninjaService.countDojoNinjas(i.getId()));
				dojoNinjaCount.put(i.getName(), ninjaCount.get(x));
				x++;
			}
		dojosNninjas.addAttribute("dnd", dojoNinjaCount);
		return "index.jsp";
	}
	
	@RequestMapping("/new/dojo")
	public String newDojo(@ModelAttribute("dojo")Dojo newDojo) {
		return "newDojo.jsp";
	}
	
	@RequestMapping(value="/dojo", method=RequestMethod.POST)
	public String createDojo(@ModelAttribute("dojo")Dojo createDojo, BindingResult result) {
		if(result.hasErrors()) {
			return "redirect:/new/dojo";
		}else {
			ninjaService.createDojo(createDojo);
			return "redirect:/";
		}		
	}
	
	@RequestMapping("/new/ninja")
	public String newNinja(@ModelAttribute("ninja")Ninja ninja, Model dojoModel) {
		List<Dojo> dojos = ninjaService.allDojos();
		dojoModel.addAttribute("dojo", dojos);
		return "newNinja.jsp";
	}
	
	@RequestMapping(value="/ninja", method=RequestMethod.POST)
	public String createNinja(@ModelAttribute("ninja")Ninja createNinja, BindingResult result) {
		if(result.hasErrors()) {
			return "redirect:/new/ninja";
		}else {
			ninjaService.createNinja(createNinja);
			return "redirect:/";
		}		
	}
	
	
	@RequestMapping("/dojo/display/{id}")
	public String showPerson(@PathVariable("id") Long id, Model model) {
		List<Ninja> dojo = ninjaService.allDojoNinjas(id);
		model.addAttribute("ninjas", dojo);
		return "showDojoNinjas.jsp";
	}
}












