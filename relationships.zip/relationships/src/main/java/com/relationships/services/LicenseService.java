package com.relationships.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.relationships.License;
import com.relationships.repositories.LicenseRepository;
@Service
public class LicenseService {
	private final LicenseRepository licenseRepository;
	

	public LicenseService(LicenseRepository licenseRepository) {
		this.licenseRepository = licenseRepository;
	}
	
	public List<License> allLicenses(){
		return licenseRepository.findAll();
	}
	
	
	public License createLicense(License L) {
		return licenseRepository.save(L);
	}
	
	public License findLicense(Long id) {
		Optional<License> optionalLicense = licenseRepository.findById(id);
		if(optionalLicense.isPresent()) {
			return optionalLicense.get();
		}else {
			return null;
		}
	}
	
	
	public License updateLicense(Long id, String name, long rating) {
		Optional<License> license = licenseRepository.findById(id);
		License updateLicense;
		if(license.isPresent()) {
			updateLicense = license.get();
		}else {
			return null;
		}
//		LocalDateTime myDateObj = LocalDateTime.now(); 
//		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-2022 HH:mm:ss");
//		Date newdate = new Date();
		return licenseRepository.save(updateLicense);
	}
	
	

}
