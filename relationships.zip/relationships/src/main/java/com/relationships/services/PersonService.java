package com.relationships.services;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.relationships.Person;
import com.relationships.repositories.PersonRepository;
@Service
public class PersonService {
	
	private final PersonRepository personRepository;

	public PersonService(PersonRepository personRepository) {
		this.personRepository = personRepository;
	}
	
	public List<Person> allPersons(){
		return personRepository.findAll();
	}

	

	public Person createPerson(Person P) {
		return personRepository.save(P);
	}
	
	public Person findPerson(Long id) {
		Optional<Person> optionalPerson = personRepository.findById(id);
		if(optionalPerson.isPresent()) {
			return optionalPerson.get();
		}else {
			return null;
		}
	}
	
	
	public Person updatePerson(Long id, String firstname, String lastname) {
		Optional<Person> person = personRepository.findById(id);
		Person updatePerson;
		if(person.isPresent()) {
			updatePerson = person.get();
		}else {
			return null;
		}
		Date newdate = new Date();
		updatePerson.setFirstName(firstname);
		updatePerson.setLastName(lastname);
		updatePerson.setUpdatedAt(newdate);
		return personRepository.save(updatePerson);
	}
	
	


}
