package com.relationships.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.relationships.License;
import com.relationships.Person;
import com.relationships.services.LicenseService;
import com.relationships.services.PersonService;


@Controller
public class RelationshipController {
	private long num;

	
	private final LicenseService licenseService;
	private final PersonService personService;
	
	public RelationshipController(LicenseService licenseService, PersonService personService) {
		this.licenseService = licenseService;
		this.personService = personService;
	}
	
	@RequestMapping("/")
	public String test() {
		return "welcome.jsp";
	}

	
	@RequestMapping("/relationship")
	public String index( Model licenseModel, @ModelAttribute("license") License license) {
		List<License> licenses = licenseService.allLicenses();
		licenseModel.addAttribute("license", licenses);
		return "index.jsp";
	}
	
	@RequestMapping(value="/person/new")
	public String newBook(@ModelAttribute("person")Person person) {
		return "newPerson.jsp";
	}
	

	@RequestMapping(value="/license/new")
	public String newBook(@ModelAttribute("license")License license, Model personModel) {
		List<Person> persons = personService.allPersons();
		personModel.addAttribute("person", persons);
		return "newLicense.jsp";
	}
	
	
	@RequestMapping(value="/person", method=RequestMethod.POST)
	public String createPerson(@Valid @ModelAttribute("person") Person thePerson, BindingResult result, RedirectAttributes redirectAttributes) {
		if(result.hasErrors()) {
			String error = "invalid input";
			redirectAttributes.addFlashAttribute("error", error);
			return "redirect:/person/new";
		}else {
			personService.createPerson(thePerson);
			return "redirect:/relationship";
		}
	}
	
	
	@RequestMapping(value="/license", method=RequestMethod.POST)
	public String createLicense(@Valid @ModelAttribute("license") License theLicense, BindingResult result, RedirectAttributes redo) {
		if(result.hasErrors()) {
			String error = "invalid input";
			redo.addFlashAttribute("error", error);
			return "redirect:/license/new";
		}else {
			num++;
			String format = String.format("%06d", num);
			theLicense.setNumber(format);
			licenseService.createLicense(theLicense);
			return "redirect:/relationship";
		}
	}
	
	
	@RequestMapping("/license/{id}")
	public String showPerson(@PathVariable("id") Long id, Model model) {
		License person = licenseService.findLicense(id);
		model.addAttribute("person", person);
		System.out.println(person.getState());
		return "showPerson.jsp";
	}
	
	


}



