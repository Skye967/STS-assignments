package com.lookify.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.lookify.lookify;

@Repository
public interface LookifyRepository extends CrudRepository<lookify, Long>{
	
	List<lookify> findAll();
	List<lookify> findAllByNameContaining(String search);
	List<lookify> findFirst10ByOrderByRatingDesc();
	List<lookify> findByTitle(String search);
	String countByrating(String search);
    Long deleteByName(String search);
    

}
