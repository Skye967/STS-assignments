package com.lookify.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.lookify.lookify;
import com.lookify.services.lookifyService;

@Controller

public class lookifyController {


	private final lookifyService LookifyService;
	
	public lookifyController(lookifyService LookifyService) {
		this.LookifyService = LookifyService;
	}
	
	@RequestMapping("/")
	public String test() {
		return "welcom.jsp";
	}

	
	@RequestMapping("/lookify")
	public String index(Model model,@ModelAttribute("search")lookify search) {
		List<lookify> lookify = LookifyService.allLookify();
		model.addAttribute("lookify", lookify);
		return "index.jsp";
	}
	
	@RequestMapping("/lookify/search")
	public String search(Model model,@ModelAttribute("search")lookify search) {
		System.out.println(search.getName());
		List<lookify> Search = LookifyService.searchLookify(search.getName());
		model.addAttribute("lookify", Search);
		return "search.jsp";
	}
	
	@RequestMapping("/lookify/topten")
		public String topTen(Model model,@ModelAttribute("search")lookify search) {
		List<lookify> topTen = LookifyService.topTen();
		model.addAttribute("lookify", topTen);
		return "topten.jsp";
	}
	
	
	@RequestMapping(value="/lookify/new")
	public String newBook(@ModelAttribute("lookify")lookify lookify) {
		return "new.jsp";
	}
	
	@RequestMapping(value="/lookify", method=RequestMethod.POST)
	public String create(@Valid @ModelAttribute("lookify") lookify theLookify, BindingResult result, RedirectAttributes redirectAttributes) {
		if(result.hasErrors()) {
			String error = "invalid input";
			redirectAttributes.addFlashAttribute("error", error);
			return "redirect:/lookify/new";
		}else {
			LookifyService.createLookify(theLookify);
			return "redirect:/lookify";
		}
	}
	
	
	@RequestMapping("/lookify/{id}")
	public String showLookify(@PathVariable("id") Long id, Model model) {
		lookify lookify = LookifyService.findLookify(id);
		model.addAttribute("lookify", lookify);
		return "show.jsp";
	}
	
	
	@RequestMapping("/lookify/{id}/edit")
	public String edit(@PathVariable("id") Long id, Model model) {
		lookify lookify = LookifyService.findLookify(id);
		model.addAttribute("lookify", lookify);
		return "edit.jsp";
	}
	
	
	@RequestMapping(value="lookify/{id}", method=RequestMethod.PUT)
	public String update(@Valid @ModelAttribute("language") lookify Lookify, BindingResult result) {
		if(result.hasErrors()) {
			return "edit.jsp";
		}else {
			LookifyService.updateLookify(Lookify.getId(), Lookify.getName(), Lookify.getRating());
			return "redirect:/languages";
		}
	}
	
	
	@RequestMapping(value="/lookify/{id}/delete", method=RequestMethod.GET)
	public String destroy(@PathVariable("id") Long id) {
		LookifyService.deleteLookify(id);
		return "redirect:/lookify";
	}

}




