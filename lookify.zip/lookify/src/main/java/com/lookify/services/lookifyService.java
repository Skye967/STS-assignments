package com.lookify.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lookify.lookify;
import com.lookify.repository.LookifyRepository;

@Service
public class lookifyService {
	
	private final LookifyRepository lookifyRepository;

	public lookifyService(LookifyRepository lookifyRepository) {
		this.lookifyRepository = lookifyRepository;
	}
	
	public List<lookify> allLookify(){
		return lookifyRepository.findAll();
	}
	
	public List<lookify> searchLookify(String search){
		return lookifyRepository.findAllByNameContaining(search);
	}
	
	public List<lookify> topTen(){
		return lookifyRepository.findFirst10ByOrderByRatingDesc();
	}
	
	public lookify createLookify(lookify L) {
		return lookifyRepository.save(L);
	}
	
	public lookify findLookify(Long id) {
		Optional<lookify> optionalLookify = lookifyRepository.findById(id);
		if(optionalLookify.isPresent()) {
			return optionalLookify.get();
		}else {
			return null;
		}
	}
	
	
	public lookify updateLookify(Long id, String name, long rating) {
		Optional<lookify> lookify = lookifyRepository.findById(id);
		lookify updateLookify;
		if(lookify.isPresent()) {
			updateLookify = lookify.get();
		}else {
			return null;
		}
		Date newdate = new Date();
		updateLookify.setName(name);
		updateLookify.setRating(rating);
		updateLookify.setUpdatedAt(newdate);
		return lookifyRepository.save(updateLookify);
	}
	
	
	public void deleteLookify(Long id) {
		Optional <lookify> deleteLookify = lookifyRepository.findById(id);
		if(deleteLookify.isPresent()) {
			lookifyRepository.deleteById(id);
		}else {
			return;
		}
	}

}











