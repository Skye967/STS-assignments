package FamiliarRouting;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/coding")
public class FamiliarRoutingController {
	@RequestMapping("")
	public String Hello(Model model) {
		model.addAttribute("dojoName", "Burbank");
		return "index.jsp";
	}
	

	@RequestMapping("/python")
	public String python() {
		return "Python/Django was awesome!";
	}

	@RequestMapping("/java")
	public String java() {
		return "java/spring is better!";
	}
	
	 @RequestMapping("/dojo/{track}")
	 public String firstPathVariable(@PathVariable("track") String track){
	 return "The " + track + " is awesome!";
	 }
	 
	 @RequestMapping("/burbank-dojo/{track}")
	 public String SecondPathVariable(@PathVariable("track") String track){
	 return track + " is Located in sothern California!";
	 }
	 
	 @RequestMapping("/san-jose/{track}")
	 public String ThirdPathVariable(@PathVariable("track") String track){
	 return track + " is the headquarters!";
	 }


}
