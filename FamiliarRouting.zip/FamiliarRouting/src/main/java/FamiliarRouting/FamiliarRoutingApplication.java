package FamiliarRouting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class FamiliarRoutingApplication {
	
	

	public static void main(String[] args) {
		SpringApplication.run(FamiliarRoutingApplication.class, args);
		
		
		
	}

}
