package com.languages.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.languages.language;
import com.languages.repository.LanguageRepository;

@Service
public class languageService {
	
	private final LanguageRepository languageRepository;

	public languageService(LanguageRepository languageRepository) {
		this.languageRepository = languageRepository;
	}
	
	public List<language> allLanguages(){
		return languageRepository.findAll();
	}
	
	public language createLanguage(language L) {
		return languageRepository.save(L);
	}
	
	public language findLanguage(Long id) {
		Optional<language> optionalLanguage = languageRepository.findById(id);
		if(optionalLanguage.isPresent()) {
			return optionalLanguage.get();
		}else {
			return null;
		}
	}
	
	
	public language updateLanguage(Long id, String name, String creator, double version) {
		Optional<language> language = languageRepository.findById(id);
		language updateLanguage;
		if(language.isPresent()) {
			updateLanguage = language.get();
		}else {
			return null;
		}
		Date newdate = new Date();
		updateLanguage.setName(name);
		updateLanguage.setCreator(creator);
		updateLanguage.setVersion(version);
		updateLanguage.setUpdatedAt(newdate);
		return languageRepository.save(updateLanguage);
	}
	
	
	public void deleteLanguage(Long id) {
		Optional <language> deleteLanguage = languageRepository.findById(id);
		if(deleteLanguage.isPresent()) {
			languageRepository.deleteById(id);
		}else {
			return;
		}
	}
}









