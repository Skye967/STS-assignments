package com.languages.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.languages.language;
import com.languages.services.languageService;

@Controller
public class languageController {


	private final languageService LanguageService;
	
	public languageController(languageService LanguageService) {
		this.LanguageService = LanguageService;
	}
	
	@RequestMapping("/")
	public String test() {
		return "index.jsp";
	}

	
	@RequestMapping("/lookify")
	public String index(Model model) {
		System.out.println("works");
		List<language> languages = LanguageService.allLanguages();
		model.addAttribute("languages", languages);
		return "index.jsp";
	}
	
	
	@RequestMapping(value="/languages/new")
	public String newBook(@ModelAttribute("language")language Language) {
		return "new.jsp";
	}
	
	@RequestMapping(value="languages", method=RequestMethod.POST)
	public String create(@Valid @ModelAttribute("language") language Language, BindingResult result) {
		if(result.hasErrors()) {
			return "new.jsp";
		}else {
			LanguageService.createLanguage(Language);
			return "redirect:/languages";
		}
	}
	
	
	@RequestMapping("/languages/{id}")
	public String showLanguage(@PathVariable("id") Long id, Model model) {
		language Language = LanguageService.findLanguage(id);
		model.addAttribute("language", Language);
		return "show.jsp";
	}
	
	
	@RequestMapping("/languages/{id}/edit")
	public String edit(@PathVariable("id") Long id, Model model) {
		language Language = LanguageService.findLanguage(id);
		model.addAttribute("language", Language);
		return "edit.jsp";
	}
	
	
	@RequestMapping(value="languages/{id}", method=RequestMethod.PUT)
	public String update(@Valid @ModelAttribute("language") language Language, BindingResult result) {
		if(result.hasErrors()) {
			return "edit.jsp";
		}else {
			LanguageService.updateLanguage(Language.getId(), Language.getName(), Language.getCreator(), Language.getVersion());
			return "redirect:/languages";
		}
	}
	
	
	@RequestMapping(value="/languages/{id}/delete", method=RequestMethod.GET)
	public String destroy(@PathVariable("id") Long id) {
		LanguageService.deleteLanguage(id);
		return "redirect:/languages";
	}
}









