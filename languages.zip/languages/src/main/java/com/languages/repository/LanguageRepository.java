package com.languages.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.languages.language;

@Repository
public interface LanguageRepository extends CrudRepository<language, Long>{
	List<language> findAll();
	List<language> findByCreator(String search);
	Long countByName(String search);
    Long deleteByName(String search);
}
