package com.eventsbelt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventsBeltApplicationTests {

	@Test
	void contextLoads() {
	}

}
