package com.eventsbelt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventsBeltApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventsBeltApplication.class, args);
	}

}
