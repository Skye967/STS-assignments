package com.eventsbelt.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.eventsbelt.models.Guest;

public interface GuestRepo extends CrudRepository<Guest, Long>{
	List<Guest> findAll();

	Guest findByEvent_idAndNinja_id(long eventId, long ninjaId);

}
