package com.eventsbelt.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.eventsbelt.models.Event;

public interface EventRepo extends CrudRepository<Event, Long>{
	List<Event> findAll();

	Event getById(long id);

	List<Event> findAllByState(String state);

	List<Event> findAllByStateNotContaining(String state);

}
