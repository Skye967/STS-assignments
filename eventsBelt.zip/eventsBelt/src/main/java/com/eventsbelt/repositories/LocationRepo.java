package com.eventsbelt.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.eventsbelt.models.Location;

public interface LocationRepo extends CrudRepository<Location, Long>{
	List<Location> findAll();

	Location findByCityAndState(String city, String state);

	Location getById(long i);

}
