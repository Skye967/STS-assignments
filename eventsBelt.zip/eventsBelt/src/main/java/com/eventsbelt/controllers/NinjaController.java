package com.eventsbelt.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.eventsbelt.models.Event;
import com.eventsbelt.models.Guest;
import com.eventsbelt.models.Location;
import com.eventsbelt.models.Ninja;
import com.eventsbelt.services.EventService;
@Controller
public class NinjaController {
	private final EventService eventService;
	public NinjaController(EventService eventService) {
		this.eventService = eventService;
	}
	
	
	@RequestMapping("/")
	public String index(@ModelAttribute("ninja") Ninja ninja) {
		return "index.jsp";
	}
	
	
	 @RequestMapping(value="/registration", method=RequestMethod.POST)
	 public String registerUser(@Valid @ModelAttribute("ninja") Ninja ninja, BindingResult result, HttpSession session) {
		 if(result.hasErrors()) {
			 return "redirect:/";
		 }else {
			 if(eventService.findLocation(ninja.getCity(), ninja.getState()) == null) {
				 Location location = new Location();
				 location.setCity(ninja.getCity());
				 location.setState(ninja.getState());
				 eventService.createLocation(location);
			 }
			 Location ninjaLocation = eventService.findLocation(ninja.getCity(), ninja.getState());
			 ninja.setLocation(ninjaLocation);
			 eventService.registerNinja(ninja);
			 if(session.getAttribute("currentUser") == null) {
				 session.setAttribute("currentUser", ninja);
				 return "redirect:/home";
			 }
		 }
		 return null;
	 }
	 
	 
	 @RequestMapping(value="/login", method=RequestMethod.POST)
	 public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password, Model model, HttpSession session, RedirectAttributes flashMessages) {
		 if(eventService.authenticateUser(email, password)) {
			 Ninja loginNinja = eventService.findByEmail(email);
			 session.setAttribute("currentUser", loginNinja);
			 return "redirect:/home";
		 } else {
			 String errors = "Incorrect Login or Password";
			 flashMessages.addFlashAttribute("error", errors);
			 return "redirect:/login";
		 }
	 }	 
	 
	 
	 @RequestMapping("/home")
	 public String home(HttpSession session, Model model, @ModelAttribute("event") Event event) {
		 model.addAttribute("thisUser", session.getAttribute("currentUser"));
		 Ninja thisNinja = (Ninja) session.getAttribute("currentUser");
		 List<Event> eventsInState = eventService.findEventsByState(thisNinja.getState());
		 model.addAttribute("stateEvents", eventsInState);
		 List<Event> eventsNotInState = eventService.findEventsNotInState(thisNinja.getState());
		 model.addAttribute("foreignEvents", eventsNotInState);
		 System.out.println(eventsNotInState);
		 return "home.jsp";
	 }	 
	 
	 
	 @RequestMapping("/logout")
	 public String logout(HttpSession session) {
		 session.invalidate();
		 return "redirect:/login";
	 }	 
	 

}
