package com.eventsbelt.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.eventsbelt.models.Comment;
import com.eventsbelt.models.Event;
import com.eventsbelt.models.Guest;
import com.eventsbelt.models.Location;
import com.eventsbelt.models.Ninja;
import com.eventsbelt.services.EventService;

@Controller
public class EventController {
	private final EventService eventService;
	
	public EventController(EventService eventService) {
		this.eventService = eventService;
	}
	
	@RequestMapping(value="/new/event", method=RequestMethod.POST)
	public String createEvent(@Valid @ModelAttribute("event") Event event, BindingResult result) {
		
		if(result.hasErrors()) {
			return "home.jsp";
		}
		if(eventService.findLocation(event.getCity(), event.getState()) == null) {
			Location newlocation = new Location();
			newlocation.setCity(event.getCity());
			newlocation.setState(event.getState());
			eventService.createLocation(newlocation);
		}
		Location eventLocation = eventService.findLocation(event.getCity(), event.getState());
		event.setLocation(eventLocation);
		eventService.createEvent(event);
		long id = event.getId();
		return "redirect:/event/" + id;
	}
	
	@RequestMapping("/event/{id}")
	public String event(@PathVariable("id") long id, Model model) {
		Event event = eventService.findEventbyId(id);
		model.addAttribute("event", event);
		return "event.jsp";
	}
	
	@RequestMapping("/join/{eventId}/{ninjaId}")
	public String joinEvent(@PathVariable("eventId") long eventId, @PathVariable("ninjaId") long ninjaId) {
		Guest newGuest = new Guest();
		newGuest.setEvent(eventService.findEventbyId(eventId));
		newGuest.setNinja(eventService.findUserById(ninjaId));
		eventService.createGuest(newGuest);
		return "redirect:/home";
	}
	
	@RequestMapping("/cancel/{eventId}/{ninjaId}")
	public String cancelEvent(@PathVariable("eventId") long eventId, @PathVariable("ninjaId") long ninjaId) {
		Guest cancelGuest = eventService.findGuestByEventAndGuest(eventId, ninjaId);
		eventService.removeGuest(cancelGuest);
		return "redirect:/home";
	}
	
	@RequestMapping("/delete/{ninjaId}/{eventId}")
	public String deleteEvent(@PathVariable("eventId") long eventId, @PathVariable("ninjaId") long ninjaId) {
		Event deleteEvent = eventService.findEventbyId(eventId);
		eventService.deleteEvent(deleteEvent);
		System.out.println(deleteEvent);
		return "redirect:/home";
	}
	
	@RequestMapping("/display/{eventId}")
	public String displayEvent(@PathVariable("eventId") long eventId, Model model, @ModelAttribute("addcomment") Comment addcomment, HttpSession session){
		Event displayEvent = eventService.findEventbyId(eventId);
		model.addAttribute("displayEvent", displayEvent);
		List<Ninja> ninjaGuests = displayEvent.getGuests();
		long guestCount = ninjaGuests.size();
		model.addAttribute("ninjaGuests", ninjaGuests);
		String guesting = "People that are attending this event: " + guestCount;
		model.addAttribute("guesting", guesting);
		model.addAttribute("currentNinja", session.getAttribute("currentUser"));
		model.addAttribute("commentList", displayEvent.getComments());
		return "display.jsp";
	}
	
	@RequestMapping(value="/comment", method=RequestMethod.POST)
	public String newComment(@Valid @ModelAttribute("addcomment") Comment addcomment, BindingResult result) {
		long eventId = addcomment.getEvent().getId();
		if(result.hasErrors()) {
			return "display.jsp";
		}
		eventService.createComment(addcomment);
		return "redirect:/display/" + eventId;
	}
	
	@RequestMapping("/edit/{ninjaId}/{eventId}")
	public String editEvent(@ModelAttribute("event") Event event, Model model, @PathVariable("ninjaId") long ninjaId, @PathVariable("eventId") long eventId, HttpSession session) {
		model.addAttribute("thisEvent", eventService.findEventbyId(eventId));
		model.addAttribute("thisNinja", session.getAttribute("currentUser"));
		return "edit.jsp";
	}
		

}









