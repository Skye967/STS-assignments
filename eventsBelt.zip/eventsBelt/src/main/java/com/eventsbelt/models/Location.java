package com.eventsbelt.models;

import java.util.Date;
import java.util.List;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="locations")
public class Location {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private String state;
    private String city;
    private Date createdAt;
    private Date updatedAt;
    @OneToMany(mappedBy="location", fetch=FetchType.LAZY)
    private List<Event> events; 
	@OneToMany(mappedBy="location", fetch = FetchType.LAZY)
	private List<Ninja> ninjas;
	
	public Location() {
		// TODO Auto-generated constructor stub
	}

	public Location(Long id, String state, String city, Long ninja_id, Long event_id, Date createdAt, Date updatedAt,
			List<Event> events, List<Ninja> ninjas) {
		super();
		this.id = id;
		this.state = state;
		this.city = city;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.events = events;
		this.ninjas = ninjas;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}


	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<Event> getEvents() {
		return events;
	}

	public void setEvents(List<Event> events) {
		this.events = events;
	}

	public List<Ninja> getNinjas() {
		return ninjas;
	}

	public void setNinjas(List<Ninja> ninjas) {
		this.ninjas = ninjas;
	}

	
}
