package com.eventsbelt.services;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

import com.eventsbelt.models.Comment;
import com.eventsbelt.models.Event;
import com.eventsbelt.models.Guest;
import com.eventsbelt.models.Location;
import com.eventsbelt.models.Ninja;
import com.eventsbelt.repositories.CommentRepo;
import com.eventsbelt.repositories.EventRepo;
import com.eventsbelt.repositories.GuestRepo;
import com.eventsbelt.repositories.LocationRepo;
import com.eventsbelt.repositories.NinjaRepo;
@Service
public class EventService {
	private final CommentRepo commentRepo;
	private final EventRepo eventRepo;
	private final GuestRepo guestRepo;
	private final LocationRepo locationRepo;
	private final NinjaRepo ninjaRepo;
	
	
	
	public EventService(CommentRepo commentRepo, EventRepo eventRepo, GuestRepo guestRepo, LocationRepo locationRepo,
			NinjaRepo ninjaRepo) {
		super();
		this.commentRepo = commentRepo;
		this.eventRepo = eventRepo;
		this.guestRepo = guestRepo;
		this.locationRepo = locationRepo;
		this.ninjaRepo = ninjaRepo;
	}

    public Ninja registerNinja(Ninja ninja) {
        String hashed = BCrypt.hashpw(ninja.getPassword(), BCrypt.gensalt());
        ninja.setPassword(hashed);
        return ninjaRepo.save(ninja);
    }
    
    // find user by email
    public Ninja findByEmail(String email) {
        return ninjaRepo.findByemail(email);
    }
    
    // find user by id
    public Ninja findUserById(Long id) {
    	Optional<Ninja> N = ninjaRepo.findById(id);
    	
    	if(N.isPresent()) {
            return N.get();
    	} else {
    	    return null;
    	}
    }
    
    // authenticate user
    public boolean authenticateUser(String email, String password) {
        // first find the user by email
        Ninja ninja = ninjaRepo.findByemail(email);
        // if we can't find it by email, return false
        if(ninja == null) {
            return false;
        } else {
            // if the passwords match, return true, else, return false
            if(BCrypt.checkpw(password, ninja.getPassword())) {
                return true;
            } else {
                return false;
            }
        }
    }

	public Event createEvent(Event E) {
		return eventRepo.save(E);
	}

	public Location findLocation(String city, String state) {
		if(locationRepo.findByCityAndState(city, state) != null) {
			Location location = locationRepo.findByCityAndState(city, state);
			return location;
		}else {
			return null;
		}
	}

	public Location createLocation(Location newlocation) {
		return locationRepo.save(newlocation);
	}

	public Location findLocationById(long i) {
		Location getLocation = locationRepo.getById(i);
		return getLocation;
	}

	public Event findEventbyId(long id) {
		Event event = eventRepo.getById(id);
		return event;
	}

	public List<Event> findEventsByState(String state) {
		List<Event> events = eventRepo.findAllByState(state);
		return events;
	}

	public Guest createGuest(Guest newGuest) {
		return guestRepo.save(newGuest);
	}

	public Guest findGuestByEventAndGuest(long eventId, long ninjaId) {
		Guest guest = guestRepo.findByEvent_idAndNinja_id(eventId, ninjaId);
		return guest;
	}

	public void removeGuest(Guest cancelGuest) {
		guestRepo.deleteById(cancelGuest.getId());
	}

	public void deleteEvent(Event deleteEvent) {
		eventRepo.deleteById(deleteEvent.getId());
	}

	public List<Event> findEventsNotInState(String state) {
		List<Event> events = eventRepo.findAllByStateNotContaining(state);
		return events;
	}

	public void createComment(Comment comment) {
		commentRepo.save(comment);
	}
    
    
    

}
